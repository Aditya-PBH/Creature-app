# Creature App

Full Stack Social Media App (Stories, Reels, Chat)

## Run Backend
cd server
npm install
node server.js

## Run App
cd mobile
npm install
npx expo start
